package com.rigor.service;

import java.util.List;

import com.rigor.model.Category;
import com.rigor.model.Feedback;

public interface FeedbackService {

	public Feedback save(Feedback model);

	public List<Feedback> getAllData();

	List<Category> categoryList(String dept_id);

	List<Feedback> getDataByDeptId(String dept_id);

	List<Feedback> getDataByUserId(String user_id);

	public void cancel(String feedback_id);
}
