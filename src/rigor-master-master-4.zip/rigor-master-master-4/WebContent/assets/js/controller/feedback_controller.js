'use strict';
App.controller('FeedbackCtrl', [
		'$scope',
		'FeedbackService','$mdDialog','SweetAlert','$window',
		function($scope, FeedbackService,$mdDialog,SweetAlert,$window) {
			$scope.feedback = {
					fb:{feedback_id : '',feedback_type:'',description : ''},
					cat:{category_id:''},
					dept:{dept_id:''},
					
			};
			$scope.type_list=["Suggestion","Complain"];
			$scope.pageSize=3;
		
			$scope.dept_list=[];
			$scope.cat_list=[];
			//-----------load Category options----------
			
			$scope.loadCatList=function(id){
				$scope.feedback.cat.category_id='';
				FeedbackService.categoryList(id).then(function(data) {
					$scope.cat_list = data;
				}, function(errResponse) {
					console.error('Error while fetching categories');
				});
			};
			
		
			//----------load Department options--------------
			$scope.loadDeptsList=function(){
				FeedbackService.departmentList().then(function(data) {
					$scope.dept_list = data;
				}, function(errResponse) {
					console.error('Error while fetching categories');
				});
			};
			
			$scope.loadDeptsList();
			
			// ------------Create new feedback --------------
			$scope.create = function(feedback) {
				FeedbackService.create(feedback).then(function(status){
					if(status==201){
						SweetAlert.swal("Data Saved!", "You created a feedback!", "success");
						SweetAlert.swal({
							   title: "Data Saved!",
							   text: "You created a feedback!",
							   type: "success",
							   showCancelButton: false,
							   confirmButtonColor: "#DD6B55",
							   confirmButtonText: "Click to View List",
							   closeOnConfirm: true}, 
							   function(){ 
								   $window.location.href = 'http://localhost:8080/RigorProject/feedback_list';
							   });
						
					}else{
						SweetAlert.swal("Data not saved!", "Something went wrong!", "error");
					}
					
				});
			};
			// ------------Submit form in feedback_form.jsp--------------
			$scope.submit = function() {

				if ($scope.feedback.fb.feedback_id == '') {
					console.log('Saving New feedback', $scope.feedback);
					$scope.create($scope.feedback);
				} 

			};
			$scope.reset = function() {
				$scope.feedback = {
						fb:{feedback_id : '',feedback_type:'',description : ''},
						cat:{category_id:''},
						dept:{dept_id:''},
						
				};
				$scope.feedbackForm.$setPristine(); // reset Form
			};

} ]);