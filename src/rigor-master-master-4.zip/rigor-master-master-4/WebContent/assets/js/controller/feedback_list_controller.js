'use strict';
App.controller('FeedbackListCtrl', [
		'$scope',
		'FeedbackService','$mdDialog','SweetAlert',
		function($scope, FeedbackService,$mdDialog,SweetAlert) {
			$scope.feedback = {
					fb:{feedback_id : '',feedback_type:'',description : ''},
					cat:{category_id:''},
					dept:{dept_id:''},
					
			};
			
			$scope.pageSize=3;
		
			
			$scope.feedback_list=[];
		
			var user_id=$scope.user_id;
			var user_role=$scope.user_role;
			var user_dept_id=$scope.user_dept_id;
			
			// ------------Fetch all feedback  data--------------
			$scope.fetchAllData = function() {
				FeedbackService.fetchAllData().then(function(d) {	
					$scope.feedback_list = d;
				}, function(errResponse) {
					console.error('Error while fetching all data feedabck');
				});
			};
			// ------------Fetch  feedback  data by dept_id--------------
			$scope.fetchDataByDeptID = function(user_dept_id) {
				FeedbackService.fetchDataByDeptId(user_dept_id).then(function(d) {	
					$scope.feedback_list = d;
				}, function(errResponse) {
					console.error('Error while fetching dept_list in feedback');
				});
			};
			// ------------Fetch  feedback  data by user-id--------------
			$scope.fetchDataByUserId = function(user_id) {
				FeedbackService.fetchDataByUserId(user_id).then(function(d) {	
					$scope.feedback_list = d;
				}, function(errResponse) {
					console.error('Error while fetching user_list in feedback');
				});
			};

			
			if(user_role=='Administrator'){
				$scope.fetchAllData();
			}else if(user_role=='Manager'){
				$scope.fetchDataByDeptID(user_dept_id);
			}else {
				$scope.fetchDataByUserId(user_id);
			}
			// ------------Cancel feedback  data-------------
			$scope.cancel = function(id) {
				SweetAlert.swal({
					   title: "Do you want to cancel feedback of "+id+"?",
					   text: "You cannot undo this action",
					   type: "warning",
					   showCancelButton: true,
					   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, cancel it!",					 
					   closeOnConfirm: true
					   }, 
					   function(isConfirm){ 
						   if(isConfirm){
							   FeedbackService.cancel(id).then($scope.fetchAllData,
										function(errResponse) {
									console.error('Error while deactivating feedback.');
								}); 
						   }
					   });
				
			};
		
		    $scope.showAlert = showAlert;
		    function showAlert(description,feedback_id) {
		        alert = $mdDialog.alert()
		          .title('Feedback ID: ' +feedback_id)
		          .content('Description: '+description)
		          .ok('Close');

		        $mdDialog
		            .show( alert ).finally (function() {
		              alert = undefined;
		            });
		      }

		      // Close the specified dialog instance and resolve with 'finished' flag
		      // Normally this is not needed, just use '$mdDialog.hide()' to close
		      // the most recent dialog popup.

		      function closeAlert() {
		        $mdDialog.hide( alert, "finished" );
		        alert = undefined;
		      }

} ]);