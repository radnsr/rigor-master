'use strict';
App.controller('CategoryCtrl', [
		'$scope',
		'CategoryService','SweetAlert',
		function($scope, CategoryService,SweetAlert) {
			$scope.category = {
					cat:{category_id : '',description : ''},
					dept:{dept_id:''}
			};
			$scope.pageSize=3;
			$scope.categories = [];
			$scope.dept_list=[];
			
			//----------load Department options--------------
			$scope.loadDeptsList=function(){
				CategoryService.departmentList().then(function(data) {
					$scope.dept_list = data;
				}, function(errResponse) {
					console.error('Error while fetching categories');
				});
			};
			
			$scope.loadDeptsList();
			// ------------Fetch all category master data--------------
			$scope.fetchAllData = function() {
				CategoryService.fetchAllData().then(function(d) {
					$scope.categories = d;
				}, function(errResponse) {
					console.error('Error while fetching categories');
				});
			};

			// ------------Create new category master data--------------
			$scope.create = function(category) {

				CategoryService.create(category).then(function(status){
					if(status==201){
						SweetAlert.swal("Data Saved!", "You created a category!", "success");
						$scope.fetchAllData();	
					}else{
						SweetAlert.swal("Data not saved!", "Something went wrong!", "error");
					}
				},
						function(errResponse) {

							console.log(errResponse.data);
						});
			};
			$scope.fetchAllData();// execute the function when page loading
			// ------------Submit form in master_category.jsp--------------
			$scope.submit = function() {

				if ($scope.category.cat.category_id == '') {
					console.log('Saving New category', $scope.category);
					$scope.create($scope.category);
					$scope.reset();
				} else {
					$scope.update($scope.category, $scope.category.cat.category_id);
					console.log('category updated with id ', $scope.category.cat.category_id);
				}

				
			};
			// ------------Reset form in master_category.jsp-------------
			$scope.reset = function() {
				$scope.category = {
						cat:{category_id : '',description : ''},
						dept:{dept_id:''}
				};
				$scope.categoryForm.$setPristine(); // reset Form
			};

			// ------------Update category master data-------------
			$scope.update = function(category, id) {
				SweetAlert.swal({
					   title: "Are you sure?",
					   text: "You will be updated the category of "+id,
					   type: "warning",
					   showCancelButton: true,
					   confirmButtonColor: "#DD6B55",
					   confirmButtonText: "Yes, update it!",
					   closeOnConfirm: false}, 
					   function(isConfirm){ 
						   if (isConfirm) {
							   CategoryService.update(category, id).then(function(status){
									if(status==200){
										SweetAlert.swal("Category updated!", "You updated a category of "+id, "success");
										$scope.fetchAllData();
										$scope.reset();
									}else{
										SweetAlert.swal("Category not updated!", "Please contact administrator!", "error");
									}
								},
										function(errResponse) {
											console.error('Error while updating category.');
										}); 
						   } 
					   });
				
			};
			// ------------Deactvaite category master data-------------
			$scope.deactivate = function(id) {
				SweetAlert.swal({
					   title: "Are you sure?",
					   text: "Your will be deactivate the category of "+id,
					   type: "warning",
					   showCancelButton: true,
					   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, deactivate it!",					 
					   closeOnConfirm: false
					   }, 
					function(isConfirm){ 
						   if (isConfirm) {
								CategoryService.deactivate(id).then(function(status){
									if(status==200){
										SweetAlert.swal("Category deactivated","You deactivated the category of "+id,"success");
										$scope.fetchAllData();									}else{
										SweetAlert.swal("Category is not deactivated","Please contact administrator","error");

									}
								},
										function(errResponse) {
									console.error('Error while deactivating category.');
								});
						   }});
	
			};
			// ------------Deactvaite category master data-------------
			$scope.activate = function(id) {
				SweetAlert.swal({
					   title: "Are you sure?",
					   text: "Your will be activate the category of "+id,
					   type: "warning",
					   showCancelButton: true,
					   confirmButtonColor: "#DD6B55",confirmButtonText: "Yes, activate it!",					 
					   closeOnConfirm: false,
					   closeOnCancel: true 
					   }, 
					function(isConfirm){ 
						   if (isConfirm) {
								CategoryService.activate(id).then(function(status){
									if(status==200){
										SweetAlert.swal("Category activated","You activated the category of "+id,"success");
										$scope.fetchAllData();									}else{
										SweetAlert.swal("Category is not activated","Please contact administrator!","error");

									}
								},
										function(errResponse) {
									console.error('Error while deactivating category.');
								}); 
						   }
						   });

			};
			// Edit the form in master_category.jsp
			$scope.edit = function(id) {
				console.log('id to be edited', id);
				for (var i = 0; i < $scope.categories.length; i++) {
					if ($scope.categories[i][0] == id) {
						var clone = angular.copy($scope.categories[i]);
						
						$scope.category = {
								cat:{category_id : clone[0],description : clone[1]},
								dept:{dept_id:clone[2]}
						};
						break;
					}
				}
			};
} ]);