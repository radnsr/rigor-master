'use strict';
App.factory('FeedbackService', [
		'$http',
		'$q',
		function($http, $q) {

			return {
				fetchDataByUserId : function(user_id) {
					return $http
					.get('http://localhost:8080/RigorProject/feedback_user/'+user_id)
					.then(function(response) {
						return response.data;
					}, function(errResponse) {
						console.log('Error while fetching user_list feedabck service');
						return $q.reject(errResponse);
					});
				},
				fetchDataByDeptId : function(dept_id) {
					return $http
					.get('http://localhost:8080/RigorProject/feedback_dept/'+dept_id)
					.then(function(response) {
						return response.data;
					}, function(errResponse) {
						console.error('Error while fetching depts');
						return $q.reject(errResponse);
					});
				},
				categoryList : function(dept_id) {
					return $http
							.get('http://localhost:8080/RigorProject/category_list/'+dept_id)
							.then(function(response) {
								return response.data;
							}, function(errResponse) {
								console.error('Error while fetching depts');
								return $q.reject(errResponse);
							});
				},
				departmentList : function() {
					return $http
							.get('http://localhost:8080/RigorProject/dept_list/')
							.then(function(response) {
								return response.data;
							}, function(errResponse) {
								console.error('Error while fetching depts');
								return $q.reject(errResponse);
							});
				},
				create : function(data) {
					return $http.post(
							'http://localhost:8080/RigorProject/feedback/',
							data).then(function(response) {
						console.log(response);
						return response.status;
					}, function(errResponse) {

						console.error('Error while creating category');
						return $q.reject(errResponse);
					});
				},
				fetchAllData : function() {
					return $http.get(
							'http://localhost:8080/RigorProject/feedback/')
							.then(function(response) {
								return response.data;
							}, function(errResponse) {
								console.error('Error while fetching category');
								return $q.reject(errResponse);
							});
				},
			
				cancel : function(id) {
					return $http.get(
							'http://localhost:8080/RigorProject/feedback_cancel/'
									+ id).then(function(response) {
						return response.data;
					}, function(errResponse) {
						console.error('Error while deactivating category');
						return $q.reject(errResponse);
					});

				}
			}
		} ]);